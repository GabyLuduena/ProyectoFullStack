<h1>Taller HTML en 30 minutos</h1>

<h2>Repositorio creado para el taller de HTML en 30 minutos de ConquerBlocks</h2>

<img width="450px" src="https://github.com/bienvenidosaez/conquerblocks-tallerhtml/blob/master/recursos/resultado-final.jpg" alt="Portada del módulo de HTML" />

<img src="https://img.shields.io/badge/html5-%23E34F26.svg?style=for-the-badge&amp;logo=html5&amp;logoColor=white" alt="HTML5">
